# 🏍️ Aerox V2 Maintenance Tracker

A premium, mobile-first Progressive Web App (PWA) for tracking Yamaha Aerox V2 maintenance.

## ✨ Features
- 📊 Dashboard with health gauge & priority alerts
- 🔧 Maintenance tracker (12 parts grouped by category)
- 📈 Charts — frequency, distribution, timeline
- 📋 Maintenance history log with filters
- 🛢️ Engine oil performance tracker with brand & additive logging
- ⏱️ Warm-up timer (Taglish UI)
- 🌙 Dark / light mode
- 💾 Full offline support (PWA)
- 📤 Export / Import JSON backup

## 🚀 Live App
**[Open App →](https://YOUR-USERNAME.github.io/aerox-v2-tracker/)**

## 📱 Install on Phone

### iPhone (Safari)
1. Open the app link in Safari
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add**

### Android (Chrome)
1. Open the app link in Chrome
2. Tap **⋮ menu**
3. Tap **"Add to Home Screen"** or **"Install App"**
4. Tap **Add**

Once installed, the app works **100% offline**. All data is stored locally on your device.

## 📂 Files
| File | Purpose |
|------|---------|
| `index.html` | Main app (single file) |
| `manifest.json` | PWA manifest |
| `sw.js` | Service worker (offline caching) |
| `icon-192.png` | App icon (small) |
| `icon-512.png` | App icon (large) |

## 💾 Data Backup
Use the **Export** button in the app to download a JSON backup. Store it safely — you can re-import it anytime.

## 🔧 Deployment (GitHub Pages)
1. Upload all files to a GitHub repository
2. Go to **Settings → Pages**
3. Set source to `main` branch, root folder
4. Your app will be live at `https://username.github.io/repo-name/`
